<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'wp' );

/** MySQL database username */
define( 'DB_USER', 'root' );

/** MySQL database password */
define( 'DB_PASSWORD', '' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         ';pg5&1vR&@{=pl]B =Y|%V`eg5fc_^/Cqd+n0f73o9XQzn@P[Ng!=2d,u4}6fRjI' );
define( 'SECURE_AUTH_KEY',  '/R@3;O?ah1uq}I9v]kNwQZ^2,=%{!VfOj5#5zs9}<4W&9-{P>1lP;jwc1p;`@Zg[' );
define( 'LOGGED_IN_KEY',    '7;Jfzot%^9h)f*p}B[3wJ*Pn2$O^)WCr+K8KUtn8VVy[-^d_i=DwU(;es{8eA?CV' );
define( 'NONCE_KEY',        'iWsS5=~rB2;`HD87+uMsdIxzboHuy(zYcZNO[Jp|vNCv3_#,P^$[j080#XOQOo$h' );
define( 'AUTH_SALT',        ' #.XeN5eQxQI~H;=OaPZjXPGNO(W]2kI@vD#boc0)zzvd_hp4(NI1*7*o-H0_X3;' );
define( 'SECURE_AUTH_SALT', 'e%Rq0Yq.`6po_<v<EeuI4!7u#eE!8Dai*Aa}I+5~$)=6O/:]lvm9<o%{$1Ce.G)n' );
define( 'LOGGED_IN_SALT',   '4JaZbuq}~mn?Zl}^A<:025c[U,lyi+8K^yDY;-o[oEl23]%=u^]f4<z>`@YO_Lv/' );
define( 'NONCE_SALT',       'E_2QvTxZ<LQeauU>DZnO >sfuyo_gD:P%`HXO9_fi}NN)f8V)o3f<R7rFwY%=8I4' );

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
